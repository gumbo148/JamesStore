**To delete a draft configuration**

The following command deletes a draft configuration for an environment named ``my-env``::

  aws elasticbeanstalk delete-environment-configuration --environment-name my-env --application-name my-app
